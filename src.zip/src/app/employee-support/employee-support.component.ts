import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-support',
  templateUrl: './employee-support.component.html',
  styleUrls: ['./employee-support.component.css']
})
export class EmployeeSupportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
