import { ContactComponent } from './contact/contact.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from "./home/home.component";
import {SupportComponent} from "./support/support.component";
import {UsersComponent} from "./users/users.component";
import {HttpClientModule} from "@angular/common/http";
//import {PageNotFoundComponent} from './page-not-found/page-not-found.component'
import { CustomerSupportComponent } from "./customer-support/customer-support.component";
import { EmployeeSupportComponent } from "./employee-support/employee-support.component";
import { Routes } from "@angular/router";

export const applicationRoutes: Routes = [
    {path:'',redirectTo:'home', pathMatch:'full'},
    { path: 'home', component: HomeComponent },
    { path: 'about', component: AboutComponent },
    { path: 'contact', component: ContactComponent},
    { path: 'support', component: SupportComponent},
    { path: 'users', component: UsersComponent },


        //{ path: '**', component: PageNotFoundComponent }
        { path: 'support', component: SupportComponent, children: [
                { path: 'customer-support', component: CustomerSupportComponent },
                { path: 'employee-support', component: EmployeeSupportComponent }
            ]
        }



];